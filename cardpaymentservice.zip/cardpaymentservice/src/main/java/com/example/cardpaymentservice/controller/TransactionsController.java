package com.example.cardpaymentservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.cardpaymentservice.dao.TransactionsDAO;
import com.example.cardpaymentservice.model.Transactions;

@RestController
public class TransactionsController {
	@Autowired
	private TransactionsDAO transactionsDAO;
	@PostMapping("/transaction")
	public ResponseEntity addTransaction(@RequestBody Transactions transactiondDetails) {
		System.out.println("hello......");
		transactionsDAO.addTransaction(transactiondDetails);
		return new ResponseEntity(transactiondDetails, HttpStatus.OK);
	}
}

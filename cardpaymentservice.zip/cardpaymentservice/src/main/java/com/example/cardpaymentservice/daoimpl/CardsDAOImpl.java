package com.example.cardpaymentservice.daoimpl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.web.bind.annotation.RestController;

import com.example.cardpaymentservice.dao.CardsDAO;
import com.example.cardpaymentservice.model.Cards;
import com.example.cardpaymentservice.util.DBUtil;

@RestController
public class CardsDAOImpl implements CardsDAO {
	static List<Cards> list1=new ArrayList();
	Connection connection;
	
	public CardsDAOImpl() {
		connection = DBUtil.getConnection();
		System.out.println("connection" + connection);
	}	
	public List<Cards> viewAllCards(){		
		System.out.println("Inside viewAll cards");

		try {
			list1.clear();

			//System.out.println("Inside try");
			PreparedStatement stmt = connection.prepareStatement("select * from cards");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				Cards card=new Cards();
				//System.out.println("Inside while");
				card.setCardid(rs.getInt("card_id"));
				card.setCardnumber(rs.getString("card_number"));
				card.setCardholder(rs.getString("card_holder"));
				card.setCardcvv(rs.getString("card_cvv"));
				card.setExpdate(rs.getDate("exp_date"));
				card.setTotalamount(rs.getString("total_bal"));
				//System.out.println("Inside while-2");
				list1.add(card);
				//System.out.println(list1);	
			}
			}catch(Exception e) {}
		return list1;
	}
	
	@Override
	public String cardValidation(String cardnumber){
		String cType = null;
		String flag="no";
		for (Cards c:list1) {
			System.out.println("Cards data----"+c);
			if (c.getCardnumber().equals(cardnumber) && cardnumber.startsWith("4")) {
				flag="yes";	
				cType="VISA";
				//return flag;
			} else if (c.getCardnumber().equals(cardnumber) && cardnumber.startsWith("5")) {
				flag="yes";	
				cType="MASTER";
			}
			/*
			 * if (cardnumber.startsWith("4")) { cType = "VISA"; } else { cType= "MASTER"; }
			 */
		}
		System.out.println("flag="+flag);
		System.out.println("cardtype="+cType);
		//return flag;
		return flag + cType;
	}

}

package com.example.cardpaymentservice.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;

import org.springframework.web.bind.annotation.RestController;

import com.example.cardpaymentservice.dao.TransactionsDAO;
import com.example.cardpaymentservice.model.Transactions;
import com.example.cardpaymentservice.util.DBUtil;

@RestController
public class TransactionsDAOImpl implements TransactionsDAO {
Connection connection;
	
	public TransactionsDAOImpl() {
		connection = DBUtil.getConnection();
		System.out.println("connection" + connection);
	}
	public Transactions addTransaction(Transactions transactiondDetails) {
		int noOfRecords = 0;
		try {
			PreparedStatement pst = connection.prepareStatement(
					"Insert into transactions(trans_id,card_id, trans_amount, avail_amount) values(?,?,?,?)");
			pst.setInt(1, transactiondDetails.getTransid());
			pst.setInt(2, transactiondDetails.getCardid());
			pst.setFloat(3, transactiondDetails.getTransamount());
			pst.setFloat(4, transactiondDetails.getAvailamount());
			noOfRecords = pst.executeUpdate();
			System.out.println(noOfRecords + "record inserted successfully");
		} catch (Exception e) {
		}
		System.out.println(noOfRecords+"this is outside");
		return transactiondDetails;
	}
	

}

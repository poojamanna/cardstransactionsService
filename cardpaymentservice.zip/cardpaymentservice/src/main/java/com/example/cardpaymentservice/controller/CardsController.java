package com.example.cardpaymentservice.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.cardpaymentservice.dao.CardsDAO;
import com.example.cardpaymentservice.model.Cards;

@Controller
public class CardsController {

	@Autowired
	private CardsDAO cardDAO;
	
	@GetMapping("/cards")
	public List getCards(Cards cards) {
		System.out.println("cards details"+cardDAO.viewAllCards());
	return cardDAO.viewAllCards();
		//return "cards"; 
	}
	@GetMapping("/cards1/{cardnumber}")
	public ResponseEntity getCardValidation(@PathVariable ("cardnumber") String cardnumber) {
		Cards cards = null;
		getCards(cards);
		String flag=cardDAO.cardValidation(cardnumber);			
		if (flag == "no") {
			return new ResponseEntity("No Customer found for ID " + cardnumber, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(flag, HttpStatus.OK);
		//return "success";
	}
}
package com.example.cardpaymentservice.model;

public class Transactions {
	private int transid;
	private int cardid;
	private float transamount;
	private float availamount;
	
	public Transactions() {
		
	}
	public Transactions(int transid, int cardid, float transamount, float availamount) {
		super();
		this.transid = transid;
		this.cardid = cardid;
		this.transamount = transamount;
		this.availamount = availamount;
	}
	public int getTransid() {
		return transid;
	}
	public void setTransid(int transid) {
		this.transid = transid;
	}
	public int getCardid() {
		return cardid;
	}
	public void setCardid(int cardid) {
		this.cardid = cardid;
	}
	public float getTransamount() {
		return transamount;
	}
	public void setTransamount(float transamount) {
		this.transamount = transamount;
	}
	public float getAvailamount() {
		return availamount;
	}
	public void setAvailamount(float availamount) {
		this.availamount = availamount;
	}
	@Override
	public String toString() {
		return "Transactions [transid=" + transid + ", cardid=" + cardid + ", transamount=" + transamount
				+ ", availamount=" + availamount + "]";
	}
}

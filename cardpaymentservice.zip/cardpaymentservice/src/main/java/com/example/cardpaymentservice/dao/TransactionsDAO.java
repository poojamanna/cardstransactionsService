package com.example.cardpaymentservice.dao;

import com.example.cardpaymentservice.model.Transactions;

public interface TransactionsDAO {
	public Transactions addTransaction(Transactions transactiondDetails);
}
